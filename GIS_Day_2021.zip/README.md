# GIS Day 2021
To install, just run `install_demo.py` or download the whole directory and put it in `C:\Student\GISDay_2021`